详细api文档参见 <http://mcavage.me/node-restify/>

这里是一组mock数据和mock行为，它可以在开发阶段快速建立一个伪服务器。
