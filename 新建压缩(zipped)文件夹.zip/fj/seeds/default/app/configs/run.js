'use strict';

angular.module('app').run(function() {
});
