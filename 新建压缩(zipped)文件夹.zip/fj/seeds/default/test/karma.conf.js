'use strict';

module.exports = function (config) {
};
