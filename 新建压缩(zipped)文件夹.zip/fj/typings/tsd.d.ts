/// <reference path="node/node.d.ts" />
/// <reference path="gulp/gulp.d.ts" />
/// <reference path="chalk/chalk.d.ts" />
/// <reference path="q/Q.d.ts" />
