'use strict';

angular.module('app').constant('page', {
  title: ''
});
