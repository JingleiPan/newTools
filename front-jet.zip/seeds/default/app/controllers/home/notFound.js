'use strict';

angular.module('app').controller('HomeNotFoundCtrl', function HomeNotFoundCtrl($scope) {
  var vm = $scope.vm = {};

});
