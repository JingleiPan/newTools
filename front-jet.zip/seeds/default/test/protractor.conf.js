exports.config = {
  multiCapabilities: [
    {
      'browserName': 'phantomjs'
    },
    //{
    //  'browserName': 'chrome'
    //},
    //{
    //  'browserName': 'firefox'
    //},
    //{
    //  'browserName': 'ie'
    //}
  ]
};
