/// <reference path="jquery/jquery.d.ts" />
/// <reference path="angularjs/angular.d.ts" />
/// <reference path="angularjs/angular-mocks.d.ts" />
/// <reference path="restify/restify.d.ts" />
/// <reference path="node/node.d.ts" />
/// <reference path="karma-jasmine/karma-jasmine.d.ts" />
/// <reference path="jasmine/jasmine.d.ts" />
