准备实现mock功能：

1. 文件变动自动重启
1. 支持js、coffee等多种文件格式
1. 内置标准登录接口
1. 可以把任意资源直接导出为rest resource

